using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; 

namespace bookrental
{
    public class Customer
    {
        public int Id { get; set; }
        [Required]
        [StringLength(255)]
        public string Nome { get; set; }

        [Required, Range(1, 100, ErrorMessage = "You Must have more than 10 Years old")]
        public int Age{get; set;}

        public DateTime borrowDate;
        public DateTime returnDate;
        public int borrowBookId;

        public List<Book>Books {get;set;}

        public NovoClient(string name, int age){
            Nome = name;
            Age = age;
        }

        public GetDiasRestantes(DateTime dataAtual){
            TimeSpan final = Convert.ToDateTime(returnDate).Subtract(Convert.ToDateTime(dataAtual));

            return final;
        }
    }
}