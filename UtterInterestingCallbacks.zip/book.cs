using System.Collections.Generic;

namespace bookrental
{
    public class Book
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Bookcount {get;set;}

        public LoteLivros(){
          Bookcount = 15;
        }

        
        public enum category{
            English,
            Math,
            Tech,
            Programation,
            Business
        }

        public GetBooksonShelf(){
          return Bookcount;
        }
        
    }
    
}